cd .. 
cd ..
sudo ./lampp start