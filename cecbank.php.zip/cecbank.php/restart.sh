cd ..
cd ..
sudo ./lampp restart